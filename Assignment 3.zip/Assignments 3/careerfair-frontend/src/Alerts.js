import React from 'react';
import { Alert } from '@mui/material';

const Alerts = (props) => {
  const renderAlert = (condition, message, severity) => {
    return condition ? <Alert severity={severity}>{message}</Alert> : null;
  };

  return (
    <div>
      {renderAlert(props.walletError, 'Wallet Could NOT Be Connected', 'warning')}
      {renderAlert(props.addCompanyError, 'Only the owner can add a company and it must not be a duplicate', 'error')}
      {renderAlert(props.enrollError, 'You are already enrolled in the career fair', 'error')}
      {renderAlert(props.unenrollError, 'You are not enrolled in the career fair', 'error')}
    </div>
  );
};

export default Alerts;

