const ConnectWallet = (props) => {
  const renderConnectButton = () => {
    console.log("Rendering ConnectButton. Account:", props.account);

    if (!props.account) {
      console.log("No ETH wallet detected");
      return (
        <div>
          <button
            className="Connect-Button"
            onClick={async () => {
              console.log("Connecting wallet...");
              try {
                await props.connectWallet();
                console.log("ETH wallet detected", props.account);
        
              } catch (error) {
                console.error("Error connecting wallet:", error);
              }
            }}
          >
            Connect Wallet
          </button>
        </div>
      );
    } 
  };

  return <>{renderConnectButton()}</>;
};

export default ConnectWallet;



