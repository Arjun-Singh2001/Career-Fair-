// App.js
import React, { useState, useEffect } from 'react';
import './App.css';
import ConnectWallet from './ConnectWallet';
import AddCompany from './AddCompany';
import abi from './abi.json';
import { ethers } from 'ethers';
import Alerts from './Alerts';

function App() {
  const [wallets, setWallets] = useState(null);
  const [walletError, setWalletError] = useState(false);
  const [addCompanyError, setAddCompanyError] = useState(false);
  const [enrollError, setEnrollError] = useState(false);
  const [unenrollError, setUnenrollError] = useState(false);
  const [attendeesZero, setAttendeesZero] = useState(false);
  const [attendees, setAttendees] = useState([]);

  const connectWallet = async () => {
    try {
      const { ethereum } = window;

      if (ethereum && ethereum.isMetaMask) {
        const wallets = await ethereum.request({ method: 'eth_requestAccounts' });
        setWalletError(false);
        setWallets(wallets);
      } else {
        console.error('Metamask Not Installed');
      }
    } catch (error) {
      console.error('Error fetching accounts from metamask:', error);
      setWalletError(true);
    }
  };

  const checkAccounts = async () => {
    try {
      const accounts = window.ethereum._state.accounts;

      if (accounts.length === 0) {
        setWallets(null);
      }
    } catch (error) {
      // Ignore errors
    }
  };

  useEffect(() => {
    const handleAccountsChanged = (accounts) => {
      if (accounts.length === 0) {
        console.log('Please connect to MetaMask.');
      }
    };

    if (window.ethereum) {
      window.ethereum.on('accountsChanged', handleAccountsChanged);
    }

    const intervalId = setInterval(checkAccounts, 1000);

    return () => clearInterval(intervalId);
  }, []);

  const getCompanies = async () => {
    try {
      const { ethereum } = window;

      if (ethereum) {
        const provider = new ethers.providers.Web3Provider(ethereum);
        const contract = new ethers.Contract("0x0545a29d375824d75dc505a4059d82949dd7240b", abi.abi, provider);

        const companies = await contract.functions.getCompanies();
        console.log(companies[0]);
      } else {
        console.log("ETH window doesn't exist");
      }
    } catch (error) {
      console.error('Error fetching companies:', error);
    }
  };

  const getAttendees = async () => {
    try {
      const { ethereum } = window;

      if (ethereum) {
        const provider = new ethers.providers.Web3Provider(ethereum);
        const contract = new ethers.Contract("0x0545a29d375824d75dc505a4059d82949dd7240b", abi.abi, provider);

        const attendees = await contract.functions.getAttendees();
        console.log(attendees[0]);
        setAttendees(attendees[0]);

        if (attendees[0].length === 0) {
          setAttendeesZero(true);
        } else {
          setAttendeesZero(false);
        }
      } else {
        console.log("ETH window doesn't exist");
      }
    } catch (error) {
      console.error('Error fetching attendees:', error);
    }
  };

  const enroll = async () => {
    try {
      const { ethereum } = window;

      if (ethereum) {
        const provider = new ethers.providers.Web3Provider(ethereum);
        const signer = provider.getSigner();
        const contract = new ethers.Contract("0x0545a29d375824d75dc505a4059d82949dd7240b", abi.abi, signer);

        const enrollTxn = await contract.functions.enroll();
        await enrollTxn.wait();

        setEnrollError(false);
      } else {
        console.log("ETH window doesn't exist");
      }
    } catch (error) {
      setEnrollError(true);
    }
  };

  const unenroll = async () => {
    try {
      const { ethereum } = window;

      if (ethereum) {
        const provider = new ethers.providers.Web3Provider(ethereum);
        const signer = provider.getSigner();
        const contract = new ethers.Contract("0x0545a29d375824d75dc505a4059d82949dd7240b", abi.abi, signer);

        const unenrollTxn = await contract.functions.unenroll();
        await unenrollTxn.wait();

        setUnenrollError(false);
      } else {
        console.log("ETH window doesn't exist");
      }
    } catch (error) {
      setUnenrollError(true);
    }
  };

  const addCompany = async (company) => {
    console.log('adding');
    try {
      const { ethereum } = window;

      if (ethereum) {
        const provider = new ethers.providers.Web3Provider(ethereum);
        const signer = provider.getSigner();
        const contract = new ethers.Contract("0x0545a29d375824d75dc505a4059d82949dd7240b", abi.abi, signer);

        getCompanies();
        const addCompanyTxn = await contract.functions.addCompany(company);
        await addCompanyTxn.wait();
        console.log('after');
        getCompanies();
        setAddCompanyError(false);
      } else {
        console.log("ETH window doesn't exist");
      }
    } catch (error) {
      console.error('Error adding company:', error);
      setAddCompanyError(true);
    }
  };

  return (
    <div className="LandingPage">
      <header className="App-header">
        <h1>Welcome to the Career Fair</h1>
        <Alerts walletError={walletError} addCompanyError={addCompanyError} enrollError={enrollError} unenrollError={unenrollError} />
        {wallets ? (
          <div> </div>
        ) : (
          <>
            <p>Connect your wallet to get started</p>
            <ConnectWallet connectWallet={connectWallet} />
          </>
        )}

        <AddCompany addCompany={addCompany} />

        <button className="Enroll-Button" onClick={enroll}>
          Enroll
        </button>
        <button className="Unenroll-Button" onClick={unenroll}>
          Unenroll
        </button>
        <div className="SeeAttendees">
          <button className="SeeAttendees-Button" onClick={getAttendees}>
            See Attendees
          </button>
          {!attendeesZero ? (
            attendees.map((item, index) => {
              return <div key={index}> {item}</div>;
            })
          ) : (
            <div>No one is enrolled</div>
          )}
        </div>
      </header>
    </div>
  );
}

export default App;
