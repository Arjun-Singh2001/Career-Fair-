// AddCompany.js
import React, { useState } from 'react';

const AddCompany = (props) => {
  const [company, setCompany] = useState('');

  const handleSubmit = () => {
    props.addCompany(company);
  };

  const onChange = (newName) => {
    console.log(newName.target.value);
    setCompany(newName.target.value);
  };

  return (
    <div className="AddCompany-Form">
      <input type="text" name="name" value={company} onChange={onChange} placeholder="Company Name" />
      <input type="submit" value="Add Company" onClick={handleSubmit} />
    </div>
  );
};

export default AddCompany;

